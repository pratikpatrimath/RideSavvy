import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../../utility/common_widgets/common_scaffold.dart';
import '../../utility/constants/dimens_constants.dart';
import '../controller/home_controller.dart';
import '../utility/common_widgets/custom_text_field.dart';

class HomeScreen extends StatelessWidget {
  HomeScreen({super.key});

  final HomeController _controller = Get.put(HomeController());

  @override
  Widget build(BuildContext context) {
    context.theme;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _showBottomSheet();
    });

    return CommonScaffold(
      appBar: AppBar(
        title: const Text("Home"),
        centerTitle: true,
        actions: [_actionWidget()],
      ),
      body: Obx(
        () => Stack(
          children: [
            _googleMap(),
            Visibility(
              visible: _controller.isSelectLocationVisible.value,
              child: SingleChildScrollView(child: _textFields()),
            ),
            _controller.isMapLoading.value
                ? const Center(child: CircularProgressIndicator())
                : Container(),
          ],
        ),
      ),
    );
  }

  Widget _actionWidget() {
    return Padding(
      padding: const EdgeInsets.only(right: DimenConstants.mixPadding),
      child: InkWell(
        onTap: () => _controller.onTapActionBarIcon(),
        child: const Icon(Icons.directions_outlined),
      ),
    );
  }

  Widget _googleMap() {
    return GoogleMap(
      myLocationButtonEnabled: true,
      mapType: MapType.normal,
      mapToolbarEnabled: true,
      trafficEnabled: true,
      compassEnabled: true,
      myLocationEnabled: true,
      markers: Set<Marker>.of(_controller.markerList),
      polylines: Set<Polyline>.of(_controller.polylineList),
      initialCameraPosition: const CameraPosition(target: LatLng(0, 0)),
      onMapCreated: (GoogleMapController googleMapController) {
        _controller.onMapCreated(googleMapController);
      },
    );
  }

  Widget _textFields() {
    return Card(
      margin: const EdgeInsets.all(DimenConstants.contentPadding),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomTextField(
            hintText: "Start Location",
            prefixIcon: Icons.location_searching_outlined,
            textEditingController: _controller.etStartLocation,
            onTapField: () => _controller.onTapSearch(),
          ),
          CustomTextField(
            hintText: "Destination",
            prefixIcon: Icons.edit_location_alt_outlined,
            textEditingController: _controller.etDestinationLocation,
            onTapField: () => _controller.onTapSearch(isDestination: true),
          ),
          Padding(
            padding: const EdgeInsets.all(DimenConstants.contentPadding),
            child: Text(
              '* Click on direction icon on top right to hide/show this window',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.grey,
                fontSize: Get.textTheme.bodyMedium?.fontSize,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showBottomSheet() {
    showModalBottomSheet(
      enableDrag: true,
      elevation: DimenConstants.cardElevation,
      backgroundColor: Colors.white,
      context: Get.context as BuildContext,
      builder: (BuildContext buildContext) {
        return GestureDetector(
          onTap: () => Navigator.pop(buildContext),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(DimenConstants.layoutPadding),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      _vehicleTypeCard(icon: Icons.taxi_alert_outlined),
                      _vehicleTypeCard(icon: Icons.drive_eta_outlined),
                      _vehicleTypeCard(icon: Icons.local_taxi_outlined),
                    ],
                  ),
                  _comparisonText(
                    text: 'Estimate Ola Price : '
                        '${_controller.estimateOlaPrice}',
                  ),
                  _comparisonText(
                    text: 'Estimate Uber Price : '
                        '${_controller.estimateOlaPrice}',
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _vehicleTypeCard({VoidCallback? onPressed, IconData? icon}) {
    return Expanded(
      child: Card(
        child: Container(
          constraints: BoxConstraints(minWidth: Get.size.width),
          child: IconButton(
            onPressed: () => onPressed ?? {},
            icon: Icon(icon),
          ),
        ),
      ),
    );
  }

  Widget _comparisonText({required String text}) {
    return Card(
      child: Container(
        constraints: BoxConstraints(minWidth: Get.size.width),
        padding: EdgeInsets.all(DimenConstants.contentPadding),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: Get.textTheme.titleMedium?.fontSize,
          ),
        ),
      ),
    );
  }
}
