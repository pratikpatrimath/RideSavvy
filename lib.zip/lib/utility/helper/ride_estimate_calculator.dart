import '../constants/string_constants.dart';

class RideEstimateCalculator {
  static const Map<String, double> olaBaseFare = {
    StringConstants.auto: 30.0,
    StringConstants.car: 50.0,
    StringConstants.taxi: 40.0,
  };

  static const Map<String, double> olaPerKmCharge = {
    StringConstants.auto: 8.0,
    StringConstants.car: 15.0,
    StringConstants.taxi: 12.0,
  };

  static const Map<String, double> olaPerMinuteCharge = {
    StringConstants.auto: 2.0,
    StringConstants.car: 3.0,
    StringConstants.taxi: 2.5,
  };

  static const Map<String, double> uberBaseFare = {
    StringConstants.auto: 25.0,
    StringConstants.car: 45.0,
    StringConstants.taxi: 35.0,
  };

  static const Map<String, double> uberPerKmCharge = {
    StringConstants.auto: 7.0,
    StringConstants.car: 12.0,
    StringConstants.taxi: 10.0,
  };

  static const Map<String, double> uberPerMinuteCharge = {
    StringConstants.auto: 1.8,
    StringConstants.car: 2.5,
    StringConstants.taxi: 2.0,
  };

  static double calculateEstimate({
    String? service,
    String? vehicleType,
    double? distanceInMeters,
    double? totalTimeInMinutes,
  }) {
    double distanceInKm = (distanceInMeters ?? 1) / 1000;
    double? baseFare = (service == 'ola')
        ? olaBaseFare[vehicleType]
        : uberBaseFare[vehicleType];
    double? perKmCharge = (service == 'ola')
        ? olaPerKmCharge[vehicleType]
        : uberPerKmCharge[vehicleType];
    double? perMinuteCharge = (service == 'ola')
        ? olaPerMinuteCharge[vehicleType]
        : uberPerMinuteCharge[vehicleType];

    double totalDistanceCharge = distanceInKm * (perKmCharge ?? 1);
    totalTimeInMinutes = totalTimeInMinutes ?? 1;
    double totalDurationCharge = totalTimeInMinutes * (perMinuteCharge ?? 1);

    return (baseFare ?? 1) + totalDistanceCharge + totalDurationCharge;
  }

  static Map<String, double> calculateAverageEstimates({
    double? distanceInMeters,
    double? totalTimeInMinutes,
  }) {
    Map<String, double> averageEstimates = {};

    for (String type in StringConstants.vehicleList) {
      double olaEstimate = calculateEstimate(
        service: 'ola',
        vehicleType: type,
        distanceInMeters: distanceInMeters,
        totalTimeInMinutes: totalTimeInMinutes,
      );

      double uberEstimate = calculateEstimate(
        service: 'uber',
        vehicleType: type,
        distanceInMeters: distanceInMeters,
        totalTimeInMinutes: totalTimeInMinutes,
      );
      averageEstimates[type] = (olaEstimate + uberEstimate) / 2;
    }

    return averageEstimates;
  }
}
