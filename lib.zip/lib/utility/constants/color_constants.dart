import 'package:flutter/material.dart';

class ColorConstants{
  static const Color dark = Color(0xFF121212);
  static const Color accentColor = Color(0xff2c2c53);
  static const Color transparentColor = Color(0x00000000);
}