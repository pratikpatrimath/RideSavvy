class StringConstants {
  static const String appName = "Ola uber Price Comparison";
  static const String databaseName = "ola_uber_price_comparison.db";
  static const int databaseVersion = 1;

  //API
  static const String googleMapKey = "AIzaSyAhywGgq9Wijf3LMZOLVDAV8lQ8Buf5OK8";

  //ASSET
  static const String loadingLottie = 'asset/lottie/loading.json';
  static const String noResultLottie = 'asset/lottie/no_result.json';

  static const String leftTriangle = 'asset/shapes/left_triangle.json';
  static const String rightTriangle = 'asset/shapes/right_triangle.json';

  static const String logo = 'asset/images/admin.png';
  static const String upload = 'asset/images/upload.png';
  static const String adminIcon = 'asset/images/admin.png';
  static const String userIcon = 'asset/images/user.png';
  static const String signIn = 'asset/images/sign_in.png';
  static const String profile = 'asset/images/profile.png';
  static const String loading = 'asset/images/loading_image.png';
  static const String error404 = 'asset/images/error404.png';
  static const String noImage = 'asset/images/no_image.jpeg';
  static const String errorImage = 'asset/images/no_image.jpeg';

  //DATABASE
  static const String tableUserMaster = "UserMaster";
  static const String userId = "userId";
  static const String name = "name";
  static const String emailId = "emailId";
  static const String password = "password";

  //TAXI
  static const String auto = 'Auto';
  static const String car = 'Car';
  static const String taxi = 'Taxi';
  static const List<String> vehicleList = [auto, car, taxi];

  // Ola City Taxi
  static const String olaAuto = 'Auto';
  static const String olaShare = 'Share';
  static const String olaMicro = 'Micro';
  static const String olaMini = 'Mini';
  static const String olaPrimeSedan = 'Prime Sedan';
  static const String olaPrimePlay = 'Prime Play';
  static const String olaPrimeSUV = 'Prime SUV';
  static const String olaLux = 'Lux';
  static const String olaERickshaw = 'E-Rickshaw';
  static const String olaKaaliPeeliTaxi = 'Kaali Peeli Taxi';
  static const List<String> olaVehicleList = [
    olaAuto,
    olaShare,
    olaMicro,
    olaMicro,
    olaPrimeSedan,
    olaPrimePlay,
    olaPrimeSUV,
    olaLux,
    olaERickshaw,
    olaKaaliPeeliTaxi,
  ];

  // Uber City Taxi
  static const String uberGo = 'UberGo';
  static const String uberX = 'UberX';
  static const String uberXL = 'UberXL';
  static const String uberBlack = 'UberBLACK';
  static const String uberSUV = 'UberSUV';
  static const String uberPool = 'UberPOOL';
  static const String uberMoto = 'UberMOTO';
  static const String uberAuto = 'UberAUTO';
  static const List<String> uberVehicleList = [
    uberGo,
    uberX,
    uberXL,
    uberBlack,
    uberSUV,
    uberPool,
    uberMoto,
    uberAuto,
  ];
}
