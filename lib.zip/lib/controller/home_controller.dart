import 'dart:async';

import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../model/route_step.dart';
import '../utility/common_widgets/common_progress.dart';
import '../utility/helper/common_helper.dart';
import '../utility/map_helper/gps_utils.dart';
import '../utility/map_helper/map_utils.dart';
import '../utility/map_helper/poly_line_utils.dart';
import '../utility/map_helper/search_view.dart';

class HomeController extends GetxController {
  RxBool isSelectLocationVisible = true.obs;
  RxBool isBottomSheetVisible = false.obs;

  RxDouble estimateOlaPrice = 0.0.obs;
  RxDouble estimateUberPrice = 0.0.obs;

  RxBool isLoading = false.obs;
  RxBool isMapLoading = true.obs;
  Rxn<LatLng> startLatLng = Rxn();
  Rxn<LatLng> destinationLatLng = Rxn();

  RxList<Marker> markerList = <Marker>[].obs;
  RxList<RouteStep> routeStepList = <RouteStep>[].obs;
  RxList<Polyline> polylineList = <Polyline>[].obs;

  GoogleMapController? googleMapController;
  LatLng emptyLocation = const LatLng(0.0, 0.0);
  final Completer<GoogleMapController> _controller = Completer();

  late TextEditingController etStartLocation;
  late TextEditingController etDestinationLocation;

  @override
  void onInit() {
    super.onInit();
    isMapLoading.value = true;
    GpsUtils.requestLocation().then((value) => _fetchUserLocation());
    initUI();
    initListeners();
  }

  Future<void> onMapCreated(GoogleMapController googleMapController) async {
    try {
      _controller.complete(googleMapController);
      this.googleMapController = googleMapController;
      await _fetchUserLocation();
    } catch (e) {
      CommonHelper.printDebugError(e, "HomeController onMapCreated()");
    } finally {
      isMapLoading.value = false;
    }
  }

  void initUI() {
    etStartLocation = TextEditingController();
    etDestinationLocation = TextEditingController();
  }

  void initListeners() {
    startLatLng.listen((p0) => _placeMarkers());
    destinationLatLng.listen((p0) => _placeMarkers());
  }

  void onTapActionBarIcon() {
    isSelectLocationVisible.value = !isSelectLocationVisible.value;
  }

  void onTapSearch({bool? isDestination}) {
    try {
      if (googleMapController != null) {
        showSearch(
          context: Get.context as BuildContext,
          delegate: SearchView(),
        ).then((value) {
          onSearched(value: value, isDestination: isDestination);
        });
      }
    } catch (e) {
      CommonHelper.printDebugError(e, "HomeController onTapSearch()");
    } finally {
      FocusManager.instance.primaryFocus?.unfocus();
    }
  }

  Future<void> _fetchUserLocation() async {
    try {
      if (startLatLng.value == null) {
        Position? position = await GpsUtils.getCurrentLocation();
        if (position != null) {
          startLatLng.value = LatLng(position.latitude, position.longitude);
          if (startLatLng.value != emptyLocation) {
            String? address = await MapUtils.getAddressFromLatLng(
              latLng: startLatLng.value,
            );
            etStartLocation.text = address ?? "";
          }
        }
      }
    } catch (e) {
      CommonHelper.printDebugError(e, "HomeController()");
    }
  }

  void onSearched({required String value, bool? isDestination}) async {
    try {
      List<Location> locationList = await locationFromAddress(value);
      Location location = locationList.first;
      LatLng latLng = LatLng(location.latitude, location.longitude);
      if (isDestination == true) {
        etDestinationLocation.text = value;
        destinationLatLng.value = latLng;
      } else {
        etStartLocation.text = value;
        startLatLng.value = latLng;
      }
    } catch (e) {
      CommonHelper.printDebugError(e, "HomeController onSearched()");
    } finally {
      FocusManager.instance.primaryFocus?.unfocus();
    }
  }

  void _placeMarkers() {
    CommonProgressBar.show();
    markerList.clear();
    polylineList.clear();
    if (googleMapController != null) {
      _addMarker(startLatLng.value, "Starting Point");
      _addMarker(destinationLatLng.value, "Destination");
      _zoomCameraAndAddPolyLine();
    }
    CommonProgressBar.hide();
  }

  Future<void> _addMarker(LatLng? latLng, String title) async {
    if (latLng != emptyLocation) {
      Marker? marker = await MapUtils.addMarker(latLng: latLng, title: title);
      marker != null ? markerList.add(marker) : null;
    }
  }

  void cameraZoomIn(LatLng? latLng, double? zoomLength) {
    MapUtils.zoomInCamera(
      controller: googleMapController!,
      latLng: latLng,
      zoomLength: zoomLength,
    );
  }

  Future<void> _zoomCameraAndAddPolyLine() async {
    if (startLatLng.value != emptyLocation) {
      cameraZoomIn(startLatLng.value, null);
      if (destinationLatLng.value != emptyLocation) {
        routeStepList.value = await PolyLineUtils.getRouteDetails(
          origin: startLatLng.value,
          destination: destinationLatLng.value,
        );

        if (routeStepList.isNotEmpty) {
          List<Polyline>? list = await PolyLineUtils.addPolyLines(
            origin: startLatLng.value!,
            routeSteps: routeStepList,
          );

          if (list.isNotEmpty) {
            polylineList.addAll(list);
            cameraZoomIn(startLatLng.value, 12.0);
          }
        }
      }
    }
  }
}
